'use strict';
module.exports = {
    'secret': "Passphrase for encryption should be 45-50 char long",
    'database_host': 'localhost',
    'database_port': '3306',
    'database_user': 'root',
    'database_password': '',
    'database_name': '273lab1',
    'connectionLimit': 100
};