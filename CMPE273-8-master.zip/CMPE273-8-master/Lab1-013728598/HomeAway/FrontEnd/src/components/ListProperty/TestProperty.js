import React, {Component} from 'react';


import DatePicker from '../Datepicker';

class TestProperty extends Component{
   
  
    render(){
       
        return(
            <div>
            
               hello
               <DatePicker></DatePicker>         
               
                </div>
        )
    }
}

export default TestProperty;