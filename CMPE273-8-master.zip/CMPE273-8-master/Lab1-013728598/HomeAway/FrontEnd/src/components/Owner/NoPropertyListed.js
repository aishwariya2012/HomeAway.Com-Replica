import React, {Component} from 'react';


export default  class T extends Component{
   
  
    render(){
       
        return(
            <div>
            
             No Property Listed by You.
             List Your Property To Earn More.       
               
                </div>
        )
    }
}

